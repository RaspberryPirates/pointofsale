#!/bin/bash

JAVA_OPTS="-Xms128m -Xmx768m"

java $JAVA_OPTS -jar floreantpos.jar
